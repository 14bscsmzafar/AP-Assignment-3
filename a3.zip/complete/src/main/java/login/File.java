/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 *
 * @author shoaib
 */
public class File 
{
    @Id
    @GeneratedValue
    @Column(name = "file_id")
    private int fid;
    @Column
    private String name;
    @Column
    private String path;
    
    public File()
    {
    }
    
    public File(int inId, String inName, String inPath)
    {
        this.fid = inId;
        this.name = inName;
        this.path = inPath;
    }
    
    public void setName(String newName)
    {
        this.name = newName;
    }
    public String getName()
    {
        return this.name;
    }
    public void setPath(String newPath)
    {
        this.path = newPath;
    }
    public String getPath()
    {
        return this.path;
    }   
    public int getId()
    {
        return this.fid;
    }

}
