/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author shoaib
 */
@Entity
public class User 
{
    @Id
    @GeneratedValue
    private int id;
    @Column
    private String username;
    @Column
    private String password;
    
    @OneToMany(cascade = {CascadeType.ALL})
    List<File> files;
    
    public User()
    {
        this.files = new <File>ArrayList();
    }
    
    public User(String inUsername, String inPassword)
    {
        this.username=inUsername;
        this.password = inPassword;
        this.files = new <File>ArrayList();
    }
    
    public void setUsername(String newUser)
    {
        this.username = newUser;
    }
    public String getUsername()
    {
        return this.username;
    }
    
    public int getId()
    {
        return this.id;
    }
    public void setPassword(String newPassword)
    {
        this.password = newPassword;
    }
    public String getPassword()
    {
        return this.password;
    }
    public void addFile(File newPath)
    {
        this.files.add(newPath);
    }
    public List<File> getAllFiles()
    {
        return this.files;
    }
    
    public void removeFile(File delFile)
    {
        if (files.contains(delFile))
        {
            files.remove(delFile);
        }
        else 
        {
            System.out.println("The file does'nt exists!");
        }
    }
        
}
